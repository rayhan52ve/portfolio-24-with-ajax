<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Portfolio-MD.Sajid Rayhan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php echo $__env->make('Frontend.partials._layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>

<?php echo $__env->yieldContent('content'); ?>

</html>
<?php /**PATH C:\laragon\www\portfolio-24-with-ajax\resources\views/Frontend/partials/master.blade.php ENDPATH**/ ?>