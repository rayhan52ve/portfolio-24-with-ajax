<!-- Template JS Files -->
<script src="<?php echo e(asset('frontend/js/jquery-3.5.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/styleswitcher.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/preloader.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/fm.revealator.jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/masonry.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/classie.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/cbpGridGallery.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery.hoverdir.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php echo $__env->yieldPushContent('js'); ?>
<?php /**PATH C:\laragon\www\portfolio-24-with-ajax\resources\views/Frontend/partials/_layouts/script.blade.php ENDPATH**/ ?>