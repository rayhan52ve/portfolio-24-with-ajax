<!DOCTYPE html>
<html lang="en" data-url-prefix="/" data-footer="true"
<?php if(isset($html_tag_data)): ?>
    <?php $__currentLoopData = $html_tag_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    data-<?php echo e($key); ?>='<?php echo e($value); ?>'
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?> 
>

<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <title>Handyman </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('Admin.partials._layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
  </head>

  <body class="h-100">
    <div id="root" class="h-100">
      <!-- Background Start -->
      <div class="fixed-background"></div>
      <!-- Background End -->

      <div class="container-fluid p-0 h-100 position-relative">
        <div class="row g-0 h-100">
          <!-- Left Side Start -->

          <!-- Left Side End -->

          <!-- Right Side Start -->
         <?php echo $__env->yieldContent('login'); ?>
          <!-- Right Side End -->
        </div>
      </div>
    </div>

   
<?php echo $__env->make('Admin.partials._layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('js_page'); ?>
    </body>
    
    </html><?php /**PATH C:\laragon\www\portfolio-24-with-ajax\resources\views/Admin/partials/login.blade.php ENDPATH**/ ?>