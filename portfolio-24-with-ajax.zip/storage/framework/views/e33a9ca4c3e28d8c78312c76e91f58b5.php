
<?php $__env->startSection('content'); ?>

    <body class="home">
        <style>
            .home .bg {
                background-image: url('<?php echo e(@$user->image ? asset($user->image) : asset('frontend/img/img-mobile.jpg')); ?>');
                background-size: cover;
                background-repeat: no-repeat;
                background-position: top;
                height: calc(100vh - 80px);
                z-index: 111;
                border-radius: 30px;
                left: 40px;
                top: 40px;
                box-shadow: 0 0 7px rgba(0, 0, 0, .9);
            }
        </style>
        <!-- Live Style Switcher Starts - demo only -->
        <?php echo $__env->make('Frontend.partials._layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Live Style Switcher Ends - demo only -->
        <!-- Header Starts -->
        <?php echo $__env->make('Frontend.partials._layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header Ends -->
        <!-- Main Content Starts -->
        <section
            class="container-fluid main-container container-home p-0 revealator-slideup revealator-once revealator-delay1">
            <div class="color-block d-none d-lg-block"></div>
            <div class="row home-details-container align-items-center">
                <div class="col-lg-4 bg position-fixed d-none d-lg-block"></div>
                <div class="col-12 col-lg-8 offset-lg-4 home-details text-left text-sm-center text-lg-left">
                    <div>
                        <img src="img/img-mobile.jpg" class="img-fluid main-img-mobile d-none d-sm-block d-lg-none"
                            alt="my picture" />
                        <h1 class="text-uppercase poppins-font">I'm
                            <?php echo e(@$user->name); ?>.<span><?php echo e(@$user->designation); ?></span></h1>
                        <p class="open-sans-font"><?php echo e(@$user->description); ?></p>
                        <a class="button" href="<?php echo e(route('about')); ?>">
                            <span class="button-text">more about me</span>
                            <span class="button-icon fa fa-arrow-right"></span>
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Main Content Ends -->

        <?php echo $__env->make('Frontend.partials._layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portfolio-24-with-ajax\resources\views/Frontend/home.blade.php ENDPATH**/ ?>