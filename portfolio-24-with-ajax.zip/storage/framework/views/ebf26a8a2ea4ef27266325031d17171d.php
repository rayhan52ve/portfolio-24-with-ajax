
<?php $__env->startSection('content'); ?>

    <body class="about">
        <!-- Live Style Switcher Starts - demo only -->
        <?php echo $__env->make('Frontend.partials._layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Live Style Switcher Ends - demo only -->
        <!-- Header Starts -->
        <?php echo $__env->make('Frontend.partials._layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header Ends -->
        <!-- Page Title Starts -->
        <section class="title-section text-left text-sm-center revealator-slideup revealator-once revealator-delay1">
            <h1>ABOUT <span>ME</span></h1>
            <span class="title-bg">Resume</span>
        </section>
        <!-- Page Title Ends -->
        <!-- Main Content Starts -->
        <section class="main-content revealator-slideup revealator-once revealator-delay1">
            <div class="container">
                <div class="row">
                    <!-- Personal Info Starts -->
                    <div class="col-12 col-lg-5 col-xl-6">
                        <div class="row">
                            <div class="col-12">
                                <h3 class="text-uppercase custom-title mb-0 ft-wt-600">personal infos</h3>
                            </div>
                            <div class="col-12 d-block d-sm-none">
                                <img src="<?php echo e(@$users->image ? asset($users->image) : asset('frontend/img/img-mobile.jpg')); ?>"
                                    class="img-fluid main-img-mobile" alt="my picture" />
                            </div>
                            <div class="col-6">
                                <ul class="about-list list-unstyled open-sans-font">
                                    <li> <span class="title">name :</span> <span
                                            class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e($users ? $users->name : 'n/a'); ?>

                                        </span> </li>
                                    <li> <span class="title">Age :</span> <span
                                            class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e($users ? $users->age : 'n/a'); ?>

                                            Years</span> </li>
                                    <li> <span class="title">LinkedIn :</span> <span
                                            class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><a
                                                target="__blanck"
                                                href="<?php echo e(@$users->linkedin ? $users->linkedin : '#'); ?>"><?php echo e(@$users->linkedin ? 'Sajid Rayhan' : 'n/a'); ?></a></span>
                                    </li>
                                    <li> <span class="title">Git Hub :</span> <span
                                            class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block">
                                            <a target="__blanck"
                                                href="<?php echo e(@$users->nationality ? $users->nationality : '#'); ?>"><?php echo e(@$users->nationality ? 'rayhan52ve' : 'n/a'); ?></a></span>
                                    </li>
                                    <li> <span class="title">Occupation :</span> <span
                                            class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e($users ? $users->designation : 'n/a'); ?></span>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-6">
                                <ul class="about-list list-unstyled open-sans-font">
                                    <li> <span class="title">Address :</span> <span
                                            class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e($users ? $users->address : 'n/a'); ?></span>
                                    </li>
                                    <li> <span class="title">phone :</span> <span
                                            class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e($users ? $users->phone : 'n/a'); ?></span>
                                    </li>
                                    <li> <span class="title">Email :</span> <span
                                            class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e($users ? $users->email : 'n/a'); ?></span>
                                    </li>

                                    <li> <span class="title">langages :</span> <span
                                            class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e($users ? $users->languages : 'n/a'); ?></span>
                                    </li>

                                    <li> <span class="title">Freelance :</span> <span
                                            class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e($users ? $users->freelance : 'n/a'); ?></span>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-12 mt-3">
                                <a class="button" href="<?php echo e(@$users->cv ? $users->cv : 'n/a'); ?>" target="_blanck">
                                    <span
                                        class="button-text"><?php echo e(@$users->cv ? 'Download CV' : 'No CV Uploaded Yet'); ?></span>
                                    <span class="button-icon fa fa-download"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- Personal Info Ends -->
                    <!-- Boxes Starts -->
                    <div class="col-12 col-lg-7 col-xl-6 mt-5 mt-lg-0">
                        <div class="row">
                            <div class="col-6">
                                <div class="box-stats with-margin">
                                    <h3 class="poppins-font position-relative"><?php echo e($users ? $users->experience : 0); ?></h3>
                                    <p class="open-sans-font m-0 position-relative text-uppercase">
                                        years of
                                        <span class="d-block">experience</span>
                                    </p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="box-stats with-margin">
                                    <h3 class="poppins-font position-relative"><?php echo e($users ? $users->complete_project : 0); ?>

                                    </h3>
                                    <p class="open-sans-font m-0 position-relative text-uppercase">completed <span
                                            class="d-block">projects</span></p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <!-- Boxes Ends -->
                </div>
                <hr class="separator">
                <!-- Skills Starts -->
                <?php if($skills->count() > 0): ?>
                    <div class="row">
                        <div class="col-12">
                            <h3
                                class="text-uppercase pb-4 pb-sm-5 mb-3 mb-sm-0 text-left text-sm-center custom-title ft-wt-600">
                                My Skills</h3>
                        </div>
                        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-md-3 mb-3 mb-sm-5">
                                <div class="c100 p<?php echo e($skill->percentage); ?>">
                                    <span><?php echo e($skill->percentage); ?>%</span>
                                    <div class="slice">
                                        <div class="bar"></div>
                                        <div class="fill"></div>
                                    </div>
                                </div>
                                <h6 class="text-uppercase open-sans-font text-center mt-2 mt-sm-4"><?php echo e($skill->program); ?>

                                </h6>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <!-- Skills Ends -->
                <hr class="separator mt-1">
                <!-- Experience & Education Starts -->
                <?php if($experiences->count() > 0 || $educations->count() > 0): ?>
                    <div class="row">
                        <div class="col-12">
                            <h3 class="text-uppercase pb-5 mb-0 text-left text-sm-center custom-title ft-wt-600">Experience
                                <span>&</span> Education
                            </h3>
                        </div>
                        <div class="col-lg-6 m-15px-tb">
                            <div class="resume-box">
                                <ul>
                                    <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <div class="icon">
                                                <i class="fa fa-briefcase"></i>
                                            </div>
                                            <span class="time open-sans-font text-uppercase"><?php echo e($experience->time); ?>

                                            </span>
                                            <h5 class="poppins-font text-uppercase"><?php echo e($experience->title); ?> <span
                                                    class="place open-sans-font"><?php echo e($experience->sector); ?></span></h5>
                                            <p class="open-sans-font"><?php echo e($experience->description); ?> </p>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-6 m-15px-tb">
                            <div class="resume-box">
                                <ul>
                                    <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <div class="icon">
                                                <i class="fa fa-graduation-cap"></i>
                                            </div>
                                            <span class="time open-sans-font text-uppercase"><?php echo e($education->time); ?></span>
                                            <h5 class="poppins-font text-uppercase"><?php echo e($education->title); ?><span
                                                    class="place open-sans-font"><?php echo e($education->sector); ?></span></h5>
                                            <p class="open-sans-font"><?php echo e($education->description); ?></p>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <!-- Experience & Education Ends -->
            </div>
        </section>
        <!-- Main Content Ends -->

        <?php echo $__env->make('Frontend.partials._layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portfolio-24-with-ajax\resources\views/Frontend/about.blade.php ENDPATH**/ ?>