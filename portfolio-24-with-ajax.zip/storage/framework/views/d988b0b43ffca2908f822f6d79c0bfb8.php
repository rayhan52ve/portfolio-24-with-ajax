<div class="nav-content d-flex">
    <!-- User Menu Start -->
    <div id="myProfileImage" class="user-container d-flex">
        <a href="<?php echo e(route('profile')); ?>" class="d-flex user ">
            <?php if(auth()->user()->image): ?>
                <img class="profile" alt="profile" src="<?php echo e(asset(auth()->user()->image)); ?>" />
            <?php else: ?>
                <img class="profile" alt="profile" src="<?php echo e(asset('backend/img/profile/profile-6.webp')); ?>" />
            <?php endif; ?>
            <div class="name"></div>
        </a>
        <div class="dropdown-menu d-none">


        </div>
    </div>
    <!-- User Menu End -->

    <!-- Icons Menu Start -->
    <ul class="list-unstyled list-inline text-center menu-icons">

        <li class="list-inline-item">
            <a href="<?php echo e(route('index')); ?>" target="__blank" title="Visit Website">
                <i class="fa-sharp fa-solid fa-globe" data-acorn-size="18"></i>
            </a>
        </li>
        <li class="list-inline-item">
            <a href="#" id="colorButton">
                <i data-acorn-icon="light-on" class="light" data-acorn-size="18"></i>
                <i data-acorn-icon="light-off" class="dark" data-acorn-size="18"></i>
            </a>
        </li>
        <li class="list-inline-item">
            <a href="#" data-bs-toggle="dropdown" data-bs-target="#notifications" aria-haspopup="true"
                aria-expanded="false" class="notification-button">
                <div class="position-relative d-inline-flex">
                    <i data-acorn-icon="bell" data-acorn-size="18"></i>
                    <span class="position-absolute notification-dot rounded-xl"></span>
                </div>
            </a>
            <div class="dropdown-menu dropdown-menu-end wide notification-dropdown scroll-out" id="notifications">
                <div class="scroll">
                    <ul class="list-unstyled border-last-none">
                        

                    </ul>
                </div>
            </div>
        </li>
    </ul>
    <!-- Icons Menu End -->

    <!-- Menu Start -->
    <div class="menu-container flex-grow-1">
        <ul id="menu" class="menu">
            <li>
                <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(url()->current() == route('dashboard') ? 'active' : ''); ?>">
                    <i data-acorn-icon="shop" class="icon" data-acorn-size="18"></i>
                    <span class="label">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('profile')); ?>" class="<?php echo e(url()->current() == route('profile') ? 'active' : ''); ?>">
                    <i data-acorn-icon="user" class="icon" data-acorn-size="18"></i>
                    <span class="label">Profile</span>
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('educations.index')); ?>"
                    class="<?php echo e(url()->current() == route('educations.index') ? 'active' : ''); ?>">
                    <i data-acorn-icon="book-open" class="icon" data-acorn-size="18"></i>
                    <span class="label">Education</span>
                </a>

            </li>
            <li>
                <a href="<?php echo e(route('experiences.index')); ?>"
                    class="<?php echo e(url()->current() == route('experiences.index') ? 'active' : ''); ?>">
                    <i data-acorn-icon="office" class="icon" data-acorn-size="18"></i>
                    <span class="label">Experians</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('skils.index')); ?>" class="<?php echo e(url()->current() == route('skils.index') ? 'active' : ''); ?>">
                    <i data-acorn-icon="keyboard" class="icon" data-acorn-size="18"></i>
                    <span class="label">Skils</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('portfolios.index')); ?>" class="<?php echo e(url()->current() == route('portfolios.index') ? 'active' : ''); ?>">
                    <i data-acorn-icon="file-chart" class="icon" data-acorn-size="18"></i>
                    <span class="label">My Projrcts</span>
                </a>
            </li>
            
            
            <li>
                <a href="<?php echo e(route('logout')); ?>" class="">
                    <i data-acorn-icon="logout" class="icon" data-acorn-size="18"></i>
                    <span class="label">Logout</span>
                </a>
            </li>
        </ul>
    </div>
    <!-- Menu End -->

    <!-- Mobile Buttons Start -->
    <div class="mobile-buttons-container">
        <!-- Menu Button Start -->
        <a href="#" id="mobileMenuButton" class="menu-button">
            <i data-acorn-icon="menu"></i>
        </a>
        <!-- Menu Button End -->
    </div>
    <!-- Mobile Buttons End -->
</div>
<div class="nav-shadow"></div>
<?php /**PATH C:\laragon\www\portfolio-24-with-ajax\resources\views/Admin/partials/_layouts/nav.blade.php ENDPATH**/ ?>