<form id="storeAndUpdateForm" action="<?php echo e(route('experiences.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="title">Experience Type</label>
        <input type="text" name="title" class="form-control" id="" placeholder="Enter experience"
            value="<?php echo e(old('title')); ?>">
        <div class="titleError errors d-none text-danger"></div>
    </div>
    <div class="form-group">
        <label for="sector">Institute</label>
        <input type="text" name="sector" class="form-control" id="" placeholder="Institute"
            value="<?php echo e(old('sector')); ?>">
        <div class="sectorError errors d-none text-danger"></div>
    </div>
    <div class="form-group">
        <label for="description">Description</label>
        <textarea type="text" name="description" class="form-control" id="" placeholder="Description"
            value="<?php echo e(old('description')); ?>" rows="3"></textarea>
        <div class="descriptionError errors d-none text-danger"></div>
    </div>
    <div class="form-group">
        <label for="time">Years of Experience</label>
        <input type="text" name="time" class="form-control" id="" placeholder="Experience in Years"
            value="<?php echo e(old('time')); ?>">
        <div class="timeError errors d-none text-danger"></div>
    </div>

    <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</form>
<?php /**PATH C:\laragon\www\portfolio-24-with-ajax\resources\views/Admin/experience/create.blade.php ENDPATH**/ ?>