<!-- Vendor Scripts Start -->
<script src="<?php echo e(asset('backend/js/vendor/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/vendor/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/vendor/OverlayScrollbars.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/vendor/autoComplete.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/vendor/clamp.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/icon/acorn-icons.js')); ?>"></script>
<script src="<?php echo e(asset('backend/icon/acorn-icons-interface.js')); ?>"></script>
<script src="<?php echo e(asset('backend/icon/acorn-icons-commerce.js')); ?>"></script>

<script src="<?php echo e(asset('backend/js/vendor/Chart.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/vendor/chartjs-plugin-rounded-bar.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/vendor/jquery.barrating.min.js')); ?>"></script>

<!-- Vendor Scripts End -->

<!-- Template Base Scripts Start -->
<script src="<?php echo e(asset('backend/js/base/helpers.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/base/globals.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/base/nav.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/base/search.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/base/settings.js')); ?>"></script>
<!-- Template Base Scripts End -->
<!-- Page Specific Scripts Start -->

<script src="<?php echo e(asset('backend/js/cs/charts.extend.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/pages/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/common.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/base/loader.js')); ?>"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/6.0.0/bootbox.min.js"
    integrity="sha512-oVbWSv2O4y1UzvExJMHaHcaib4wsBMS5tEP3/YkMP6GmkwRJAa79Jwsv+Y/w7w2Vb/98/Xhvck10LyJweB8Jsw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>



<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>    

<?php echo $__env->yieldPushContent('js'); ?>
<?php /**PATH C:\laragon\www\portfolio-24-with-ajax\resources\views/Admin/partials/_layouts/script.blade.php ENDPATH**/ ?>